<?php
return [
    'items' => [
        'id' => 'شناسه',
        'user_id' => 'شناسه ی کاربری',
        'username' => 'نام کاربری',
        'name' => 'نام',
        'family' => 'نام خانوادگی',
        'email' => 'ایمیل',
        'gender' => 'جنسیت',
        'password' => 'رمز عبور',
        'password_confirmation' => 'تکرار رمز عبور',
        'is_admin' => 'دسترسی به مدیریت',
        'status' => 'وضعیت',
        'access_level' => 'سطح دسترسی',
        'updated_at' => 'تاریخ بروزرسانی',
        'created_at ' => 'تاریخ ایجاد',
        'mobile_number' => 'تلفن همراه',
        'postal_code' => 'کد پستی',
        'birthday' => 'تاریخ تولد',
        'address' => 'آدرس',
        'description' => 'درباره کاربر',
    ],
    'values' => [
    ],
    'messages' => [

    ]
];