<div class="dlab-bnr-inr overlay-black-middle">
    <div class="container">
        <div class="dlab-bnr-inr-entry">
            <h1 class="text-white">Courses</h1>
            <!-- Breadcrumb row -->
        @include('main_template.modules.breadcrumb')
        <!-- Breadcrumb row END -->
        </div>
    </div>
</div>