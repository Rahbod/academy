<?php

namespace App\Repositories\Interfaces;

interface HomeInterface
{
//    public function find($id);
//    public function repoGallery();
//    public function repoFilms();
//    public function repoSpeeches();
}
