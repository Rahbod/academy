<?php

use App\Course;
use Illuminate\Database\Seeder;

class CourseTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Course::truncate();

//        DB::statement('SET FOREIGN_KEY_CHECKS = 0'); // disable foreign key constraints
//
//        factory('App\Course', 20)->create();

    }
}
