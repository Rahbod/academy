<div align=right dir=rtl>{{__('questions.messages.receipt1')}}&nbsp;<span align=left dir=ltr>{{$question->pursuit_code}}</span>&nbsp;{{__('questions.messages.receipt2')}}<br>{{__('questions.messages.receipt3')}}<div>
        <hr width="450" size="1">
        <p align="justify" dir="rtl" style="font-family:tahoma; font-size:10pt;color:#000000">
            {!! nl2br($question->text) !!}
        </p>
