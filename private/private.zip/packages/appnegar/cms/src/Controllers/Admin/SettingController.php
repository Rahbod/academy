<?php

namespace Appnegar\Cms\Controllers\Admin;

use Appnegar\Cms\Controllers\AdminSettingController;

class SettingController extends AdminSettingController
{

}