<?php
namespace Appnegar\Cms\Controllers\Admin;

class CategoryController extends AdminCategoryController{

    public function __construct(){
        $this->resource='Category';
    }

}