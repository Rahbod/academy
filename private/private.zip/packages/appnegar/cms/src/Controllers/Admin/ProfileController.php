<?php

namespace Appnegar\Cms\Controllers\Admin;


use Appnegar\Cms\Controllers\AdminProfileController;


class ProfileController extends AdminProfileController
{


}