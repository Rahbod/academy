<?php

namespace Appnegar\Cms\Controllers\SystemManagement;


use Appnegar\Cms\Controllers\AdminProfileController;


class ProfileController extends AdminProfileController
{


}