<?php

namespace Appnegar\Cms\Controllers\SystemManagement;

use Appnegar\Cms\Controllers\AdminSettingController;

class SettingController extends AdminSettingController
{

}