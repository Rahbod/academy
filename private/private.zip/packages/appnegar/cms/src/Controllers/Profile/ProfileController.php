<?php

namespace Appnegar\Cms\Controllers\Profile;


use Appnegar\Cms\Controllers\AdminProfileController;


class ProfileController extends AdminProfileController
{


}